package br.com.treinos;

public enum TipoMeta {
    DISTANCIA,
    TEMPO,
    CALORIAS
}